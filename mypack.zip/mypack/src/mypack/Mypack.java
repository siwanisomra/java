/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mypack;
import Pack.A;

 class superclass
 { 
     int a,b;
    double d,c;
    public void disp()
    {
        System.out.println(" function of superclass");
    }
    public void add(int a,int b)
    {
        System.out.println(a+b);
    }
    public void add(double c,double d)
    {
        System.out.println(c+d);
    }
    public void add(int a,double c)
    {
        System.out.println(a+c);
    }
     
 }
class subclass extends superclass
{
    public void show()
    {
        System.out.println("function of subclass");
    }
}


public class Mypack{
   
   
    public static void main(String[] args) {
        A objj = new A();
        subclass obj = new subclass();
        obj.disp();
        obj.add(2,3);
        obj.add(3.5,4.2);
        obj.add(2,3.5);
        obj.show();
        objj.msg();
        
       
    }
    
}
