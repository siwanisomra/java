/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daythree;
import java.util.Scanner;
class Employee
{
 public String ename;
 public String eid;
 public void get()
 {
     Scanner s = new Scanner(System.in);
     System.out.println("enter the name of the employee");
     ename=s.next();
     System.out.println("enter the id of the employee");
     eid=s.next();
 }
 public void display()
 {
     System.out.println("employee Name = "+ename);
     System.out.println("employee id = "+eid);
 }
 
}


public class Daythree {
    
     public static void main(String[] args) {
         Employee emp[]= new Employee[5];
    Scanner sc = new Scanner(System.in);
    int i;
    String a;
    for(i=0;i<5;i++)
    {
       emp[i]=new Employee();
       emp[i].get();
        
    }
    System.out.println("enter the name to search=");
    a=sc.next();
    for(i=0;i<5;i++)
    {
        if(a.toString().equals(emp[i].ename))
        {
            System.out.println("employee is found");
            emp[i].display();
            break;
        }
        else
        {
            System.out.println("employee is not found");
        }
    }
    
     }
    
}
